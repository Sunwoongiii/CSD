#include <iostream>
#include <memory>
#include <vector>

int func1() {
    int x;
    return x;
}

void func2() {
    int* ptr = nullptr;
    std::cout << *ptr << std::endl;
}

int main() {
    int value = func1();
    std::cout << value << std::endl;
    
    func2();

    return 0;
}
