#include <iostream>
#include <limits>

int func1(int a, int b) {
    return a / b;
}

int func2() {
    int i = std::numeric_limits<int>::max();
    return i + 1;
}

void func3() {
    int *j = new int(42);
    std::cout << *j << std::endl;
}

int main() {
    int result1 = func1(10, 0);
    std::cout << result1 << std::endl;

    int result2 = func2();
    std::cout << result2 << std::endl;

    func3();

    return 0;
}
