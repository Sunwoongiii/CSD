#include <iostream>
using namespace std;

void func1(int *arr, int size)
{
    for (int i = 0; i <= size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
void func2() {
    int *p = new int;
    delete p;
    delete p;
} 

void func3()
{
    int *ptr = new int(10);
    delete ptr;
    cout << *ptr << endl;
}

int main()
{
    int arr[5] = {1, 2, 3, 4, 5};
    func1(arr, 5);

    func3();

    return 0;
}
